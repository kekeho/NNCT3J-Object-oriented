public interface Siren {
  void callSiren();
}